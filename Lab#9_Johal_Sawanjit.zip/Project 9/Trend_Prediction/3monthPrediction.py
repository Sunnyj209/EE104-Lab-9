# -*- coding: utf-8 -*-
"""
Created on Sun May  7 21:40:42 2023

@author: sunny
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# Load the data
data = pd.read_csv('COVID-19_case_counts_by_date.csv')

# Convert the 'Date' column to a datetime object with format '%m/%d/%Y'
data['Date'] = pd.to_datetime(data['Date'], format='%m/%d/%Y')

# Set the start and end dates for the analysis
start_date = '2021-01-01'
end_date = '2021-06-30'

# Convert the start and end dates to timestamps
start_timestamp = pd.Timestamp(start_date)
end_timestamp = pd.Timestamp(end_date)

# Filter the data for the specified date range
data = data.loc[(data['Date'] >= start_timestamp) & (data['Date'] <= end_timestamp)]

# Check if there are any data points for the next 3 months
data_next_3_months = data.loc[(data['Date'] > '2021-03-31') & (data['Date'] <= '2021-06-30')]
if len(data_next_3_months) == 0:
    print("No data points for the next 3 months.")
else:
    # Split the data into two parts: the first 3 months and the next 3 months
    data_first_3_months = data.loc[data['Date'] <= '2021-03-31']
    data_next_3_months = data.loc[(data['Date'] > '2021-03-31') & (data['Date'] <= '2021-06-30')]

    # Fit a linear regression model to the data from the first 3 months
    model = LinearRegression()
    X = pd.to_numeric(pd.to_datetime(data_first_3_months['Date']))
    X = X.values.reshape(-1, 1)
    y = data_first_3_months['Total_cases'].values.reshape(-1, 1)
    model.fit(X, y)

    # Make predictions for the next 3 months using the fitted model
    X_pred = pd.to_numeric(pd.to_datetime(data_next_3_months['Date']))
    X_pred = X_pred.values.reshape(-1, 1)
    y_pred = model.predict(X_pred)

    # Plot the predicted and actual data
    plt.plot(data_first_3_months['Date'], data_first_3_months['Total_cases'], label='Actual')
    plt.plot(data_next_3_months['Date'], y_pred, label='Predicted')
    plt.title('COVID-19 Cases in 2021: Actual vs Predicted')
    plt.xlabel('Month')
    plt.ylabel('Total Cases')
    plt.legend()
    plt.show()


