# -*- coding: utf-8 -*-
"""
Created on Sun May  7 22:25:19 2023

@author: sunny
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures

# Load the data
data = pd.read_csv('COVID-19_case_counts_by_date.csv')

# Convert the 'Date' column to a datetime object with format '%m/%d/%Y'
data['Date'] = pd.to_datetime(data['Date'], format='%m/%d/%Y')

# Set the start and end dates for the analysis
start_date = '2021-01-01'
end_date = '2021-06-30'

# Convert the start and end dates to timestamps
start_timestamp = pd.Timestamp(start_date)
end_timestamp = pd.Timestamp(end_date)

# Filter the data for the specified date range
data = data.loc[(data['Date'] >= start_timestamp) & (data['Date'] <= end_timestamp)]

# Split the data into two parts: January to March and April to June
data_jan_to_mar = data.loc[data['Date'].dt.month <= 3]
data_apr_to_jun = data.loc[(data['Date'].dt.month > 3) & (data['Date'].dt.month <= 6)]

# Fit a polynomial regression model to the data from January to March
X = pd.to_numeric(pd.to_datetime(data_jan_to_mar['Date']))
X = X.values.reshape(-1, 1)
y = data_jan_to_mar['Total_cases'].values.reshape(-1, 1)
polynomial_features= PolynomialFeatures(degree=6)
X_poly = polynomial_features.fit_transform(X)
model = LinearRegression()
model.fit(X_poly, y)

# Make predictions for April to June using the fitted model
X_pred = pd.to_numeric(pd.to_datetime(data_apr_to_jun['Date']))
X_pred = X_pred.values.reshape(-1, 1)
X_pred_poly = polynomial_features.transform(X_pred)
y_pred = model.predict(X_pred_poly)

# Plot the predicted and actual data
plt.plot(data_jan_to_mar['Date'], data_jan_to_mar['Total_cases'], label='Actual (January to March)')
plt.plot(data_apr_to_jun['Date'], data_apr_to_jun['Total_cases'], label='Actual (April to June)')
plt.plot(data_apr_to_jun['Date'], y_pred, label='Predicted (April to June)')
plt.title('COVID-19 Cases in the First Half of 2021: Actual vs Predicted')
plt.xlabel('Month')
plt.ylabel('Total Cases')
plt.legend()
plt.show()





