# -*- coding: utf-8 -*-
"""
Created on Sun May  7 22:25:19 2023
@author: sunny
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures

# Load the data for the full year
data_full_year = pd.read_csv('COVID-19_case_counts_by_date.csv')

# Convert the 'Date' column to a datetime object with format '%m/%d/%Y'
data_full_year['Date'] = pd.to_datetime(data_full_year['Date'], format='%m/%d/%Y')

# Filter the data for the year 2021
start_date = '2021-01-01'
end_date = '2021-12-31'

data_2021 = data_full_year.loc[(data_full_year['Date'] >= start_date) & (data_full_year['Date'] <= end_date)]

# Check if there are any data points for the next 6 months
data_next_6_months = data_2021.loc[(data_2021['Date'] > '2021-06-30') & (data_2021['Date'] <= '2021-12-31')]

if len(data_next_6_months) == 0:
    print("No data points for the next 6 months.")
else:
    # Split the data into two parts: the first 6 months and the next 6 months
    data_first_6_months = data_2021.loc[data_2021['Date'] <= '2021-06-30']
    data_next_6_months = data_2021.loc[(data_2021['Date'] > '2021-06-30') & (data_2021['Date'] <= '2021-12-31')]

    # Fit a polynomial regression model to the data from the first 6 months
    X = pd.to_numeric(pd.to_datetime(data_first_6_months['Date']))
    X = X.values.reshape(-1, 1)
    y = data_first_6_months['Total_cases'].values.reshape(-1, 1)
    polynomial_features = PolynomialFeatures(degree=5)
    X_poly = polynomial_features.fit_transform(X)
    model = LinearRegression()
    model.fit(X_poly, y)

    # Make predictions for the next 6 months using the fitted model
    X_pred = pd.to_numeric(pd.to_datetime(data_next_6_months['Date']))
    X_pred = X_pred.values.reshape(-1, 1)
    X_pred_poly = polynomial_features.transform(X_pred)
    y_pred = model.predict(X_pred_poly)

    # Plot the predicted and actual data for the year 2021
    plt.plot(data_2021['Date'], data_2021['Total_cases'], label='Actual')
    plt.plot(data_next_6_months['Date'], y_pred, label='Predicted')
    plt.title('COVID-19 Cases in 2021: Actual vs Predicted')
    plt.xlabel('Month')
    plt.ylabel('Total Cases')
    plt.legend()
    plt.show()



