import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt

# Load data
dat = pd.read_csv("loan_data_with_risk_categories.csv")

# Calculate counts of each category and sort in descending order
category_counts = dat["risk_category"].value_counts()
category_order = category_counts.index.tolist()

# Plot risk categories in descending order
sns.countplot(x="risk_category", data=dat, order=category_order)
plt.show()