# -*- coding: utf-8 -*-
"""
Created on Sun May  7 13:53:44 2023

@author: sunny
"""

import seaborn as sns
import pandas as pd
import matplotlib.pyplot as plt

# Load data
loan_data = pd.read_csv("loan_data_with_risk_categories.csv")
loan_data_sample = loan_data.sample(n=500, random_state=42)

# Create scatter plot
sns.pairplot(loan_data_sample, vars=['LOAN', 'MORTDUE', 'VALUE', 'YOJ', 'DEROG', 'DELINQ', 'CLAGE', 'NINQ', 'CLNO', 'DEBTINC'], hue='risk_category')
plt.show()