# -*- coding: utf-8 -*-
"""
Created on Sun May  7 11:01:44 2023

@author: sunny
"""

import pandas as pd

# Load the loan data from a CSV file
loan_data = pd.read_csv('hmeq.csv')

# Calculate the default rate for the entire dataset
default_rate = loan_data['BAD'].mean()

# Calculate the default rate for each categorical feature
reason_defaults = loan_data.groupby('REASON')['BAD'].mean()
job_defaults = loan_data.groupby('JOB')['BAD'].mean()

# Calculate the default rate for each numerical feature
loan_defaults = loan_data.groupby(pd.qcut(loan_data['LOAN'], 4))['BAD'].mean()
debtinc_defaults = loan_data.groupby(pd.qcut(loan_data['DEBTINC'], 4))['BAD'].mean()

# Assign risk categories based on the default rates for each loan application
def assign_risk_category(row):
    if row['REASON'] == 'HomeImp' and row['JOB'] in ('Other', 'ProfExe'):
        if row['LOAN'] <= 30600 and row['DEBTINC'] <= 28.5:
            return 'low risk'
        elif row['LOAN'] > 30600 or row['DEBTINC'] > 28.5:
            return 'medium risk'
    elif row['REASON'] == 'DebtCon' and row['JOB'] in ('Other', 'ProfExe'):
        if row['LOAN'] <= 17000 and row['DEBTINC'] <= 34.5:
            return 'low risk'
        elif row['LOAN'] > 17000 or row['DEBTINC'] > 34.5:
            return 'medium risk'
    else:
        return 'high risk'

# Add a new column with the risk category for each loan
loan_data['risk_category'] = loan_data.apply(assign_risk_category, axis=1)

# Save the loan data with risk categories to a new CSV file
loan_data.to_csv('loan_data_with_risk_categories.csv', index=False)

# Output the loan data with risk categories
print(loan_data)

